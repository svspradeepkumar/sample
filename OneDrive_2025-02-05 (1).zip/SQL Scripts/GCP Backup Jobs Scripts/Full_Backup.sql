USE [msdb]
GO

/****** Object:  Job [@@Full_Backup]    Script Date: 9/10/2020 12:38:47 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 9/10/2020 12:38:47 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'@@Full_Backup', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Check If AG Primary]    Script Date: 9/10/2020 12:38:47 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Check If AG Primary', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=2, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF (select hars.role_desc from 
sys.dm_hadr_availability_replica_states hars
join sys.availability_replicas ar 
	on ar.replica_id = hars.replica_id 
	and ar.replica_server_name = SERVERPROPERTY(''ComputerNamePhysicalNetBIOS'')) <> ''Primary''
    BEGIN
       -- Secondary node, throw an error
       raiserror (''Not the AG primary'', 2, 1)
    END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Fullbackup Cleanup]    Script Date: 9/10/2020 12:38:47 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Fullbackup Cleanup', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#Get-ChildItem -Path R:\MSSQL\BACKUP\Full_Backup -Recurse -File -Force | Where-Object{$_.CreationTime -lt (Get-Date).AddDays(-1)} | Where-Object{$_.Mode -ne "-a---"} | Select-Object FullName, CreationTime, Mode |  format-table
$Retention = 2
$IsArchived = 0
$FilePath = "R:\MSSQL\BACKUP\FULL_Backup"
$Extension = ".bak"
if ($IsArchived -eq 1)
{
$files = Get-ChildItem -Path  $FilePath -Recurse -Force | Where-Object{$_.Extension -contains $Extension -and $_.LastWriteTime -lt (Get-Date).AddDays(-$Retention) -and $_.Mode -ne "d----" -and $_.mode -ne "-a---"} | Select-Object FullName | Sort-Object -Property CreationTime -Descending <#| format-table#>
}
else
{
$files = Get-ChildItem -Path  $FilePath -Recurse -Force | Where-Object{$_.Extension -contains $Extension -and $_.LastWriteTime -lt (Get-Date).AddDays(-$Retention) -and $_.Mode -ne "d----"} | Select-Object FullName | Sort-Object -Property FullName <#| format-table#>
}
if ($files.Count -eq 0)
{
    
}
else 
{
    foreach($file in $files)
    { 
    Remove-Item $file.FullName
    #Write-Host $file.FullName
    }
} 
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FullBackup]    Script Date: 9/10/2020 12:38:47 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FullBackup', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec dbadmin..[usp_Backups] @path = ''R:\MSSQL\BACKUP\'', @bkpType = ''FULL'', @dbType = ''ALL'', @compression = 1, @debug = 0', 
		@database_name=N'master', 
		@output_file_name=N'D:\MSSQL\MSSQL14.MSSQLSERVER\MSSQL\JOBS\Fullbackup.log', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Copy to bucket]    Script Date: 9/10/2020 12:38:47 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Copy to bucket', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'$BackupFolderName = ''R:\MSSQL\BACKUP\''
$ProjectName = Get-GceMetadata -path "project/project-id"
$ProjectName = $ProjectName.Substring(0,$ProjectName.Length - 5)

$BucketFolderName = Get-Cluster -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name
if (! $BucketFolderName ) { $BucketFolderName = $env:COMPUTERNAME }
$BucketFolderName = $BucketFolderName.ToUpper()

gsutil -m rsync -r $BackupFolderName gs://$ProjectName-backup/$BucketFolderName/', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Weekly', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20180313, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'f241cca4-ce5c-400c-9f99-c30dfcbd84b8'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO
